package pieces;

import java.util.ArrayList;

import board.Board;
import board.BoardUtils;
import board.MajorMove;
import board.Move;

/**
 * Trida reprezentujici pesaka.
 * @author Jan Janis
 *
 */
public class Pawn extends Piece {
	/** mozne indexy poli v sachovnici, na ktere se muze pesak pohnout (z pohledu jeho aktualni pozice) */
	private final static int[] POSSIBLE_MOVE_INDEXES = {8};
	
	
	public Pawn(int pieceIndex, Colors pieceColor) {
		super(pieceIndex, pieceColor);
	}

	@Override
	public ArrayList<Move> generateViableMoves(Board board) {
		// kolekce moznych tahu
		final ArrayList<Move> viableMoves = new ArrayList<>();
		
		for (int currentPossibleOffset : POSSIBLE_MOVE_INDEXES) {
			//index pole, na ktere muze jezdec tahnout
			int possibleDestinationIndex = this.pieceIndex + (this.getPieceColor().getDirection() * currentPossibleOffset);
			
			//pokud je index pole platny
			if(!BoardUtils.isValidTileIndex(possibleDestinationIndex)) {
				continue;
			}
			
			//pokud neni pole destinace obsazene
			if(currentPossibleOffset == 8 && !board.getTile(possibleDestinationIndex).isOccupied()) {
				viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));
			}
		}
		
		return null;
	}

}
