package pieces;

import java.util.ArrayList;

import board.AttackMove;
import board.Board;
import board.BoardUtils;
import board.MajorMove;
import board.Move;
import board.Tile;

/**
 * Trida reprezentujici kralovnu
 * @author Jan Janis
 *
 */
public class Queen extends Piece {
	/** mozne indexy poli v sachovnici, na ktere se muze kralovna pohnout (z pohledu jeho aktualni pozice) */
	private final static int[] POSSIBLE_MOVE_INDEXES = {-9, -8, -7, -1, 1, 7, 8, 9};
	
	public Queen(int pieceIndex, Colors pieceColor) {
		super(pieceIndex, pieceColor);
	}

	@Override
	public ArrayList<Move> generateViableMoves(Board board) {
		// kolekce moznych tahu
		final ArrayList<Move> viableMoves = new ArrayList<>();

		for(int possibleIndexOffset : POSSIBLE_MOVE_INDEXES) {
			//index pole, na ktere muze jezdec tahnout
			int possibleDestinationIndex = this.pieceIndex;

			// projde kazdy platny index v kazdem z 8 moznych smeru pohybu kralovny
			while(BoardUtils.isValidTileIndex(possibleDestinationIndex)) {
			
				if(isFirstColumnExclusion(possibleDestinationIndex, possibleIndexOffset) || isEighthColumnExclusion(possibleDestinationIndex, possibleIndexOffset)) {
					break;
				}
				possibleDestinationIndex += possibleIndexOffset;

				if(BoardUtils.isValidTileIndex(possibleDestinationIndex)) {
					final Tile possibleDestinationTile = board.getTile(possibleDestinationIndex);

					//pokud neni pole obsazeno, prida mozny tah do kolekce
					if(!possibleDestinationTile.isOccupied()) {
						viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));
					}
					//pokud je pole obsazeno, vyhodnoti pole a prerusi smycku
					else {
						//figura na poli o moznem indexu tahu
						final Piece pieceAtDestination = possibleDestinationTile.getPiece();
						//barva teto figury
						final Colors pieceColor = pieceAtDestination.getPieceColor();

						//pokud je figura (na poli o moznem indexu) jine barvy, nez aktualni figura, prida mozny utocny tah do kolekce
						if(this.pieceColor != pieceColor) {
							viableMoves.add(new AttackMove(board, this, possibleDestinationIndex, pieceAtDestination));
						}
						break;
					}
				}
			}
		}
		return viableMoves;
	}

	/**
	 * Tyto metody slouzi k vylouceni neplatnych tahu (tzn. neplatnych indexu cilovych poli) kralovny
	 * @param currentIndex soucasny index pole, na kterem je figura
	 * @param possibleOffset mozny index pole destinace
	 * @return true, pokud se nachazi figura v prislusnem sloupci (0,7) a zaroven se mozny index destinace rovna jednomu ze "zakazanych" indexu (takovych, ktere jsou mimo dosah tahu kralovny)
	 * 		   pokud se figura nenachazi v prislusnem sloupci, nebo se mozny index destinace rovna jednomu ze zakazanych indexu, vraci false     
	 */
	private static boolean isFirstColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.FIRST_COLUMN[currentIndex] && (possibleOffset == -9 || possibleOffset == -1 || possibleOffset == 7);
	}

	private static boolean isEighthColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.EIGHTH_COLUMN[currentIndex] && (possibleOffset == -7 || possibleOffset == 1 || possibleOffset == 9);
	}
}
