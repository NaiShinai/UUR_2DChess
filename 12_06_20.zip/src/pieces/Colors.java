package pieces;

/**
 * Vycet predstavujici barvy
 * @author Jan Janis
 *
 */
public enum Colors {
	BLACK {
		@Override
		public int getDirection() {
			return 1;
		}
	}, 
	WHITE {
		@Override
		public int getDirection() {
			return -1;
		}
	};
	
	/**
	 * Metoda, ktera vraci prirozeny smer pohybu figur
	 * @return -1 pro bile (tahnou "nahoru", takze do mensich indexu)
	 * 			1 pro cerne (tahnou "dolu", takze do vetsich indexu)
	 */
	public abstract int getDirection();
}
