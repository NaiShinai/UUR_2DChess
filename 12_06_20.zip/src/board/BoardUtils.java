package board;

/**
 * Trida predstavujici pomucky ktere vyuziva sachovnice
 * @author Jan Janis
 *
 */

public class BoardUtils {
	/** pole booleanu reprezentujici prvni, druhy, sedmy a osmy sloupec
	 *  pole jsou velikost 64 (jako sachovnice)
	 *  pole FIRST_COLUMN obsahuje na indexech prvniho sloupce hodnoty true, na vsech ostatnich false
	 *  obdobne je to pro ostatni sloupce
	 */
	public static final boolean[] FIRST_COLUMN = generateColumnArray(0);
	public static final boolean[] SECOND_COLUMN = generateColumnArray(1);
	public static final boolean[] SEVENTH_COLUMN = generateColumnArray(6);
	public static final boolean[] EIGHTH_COLUMN = generateColumnArray(7);
	
	/** pole booleanu reprezentujici prvni a osmou radku, obdobne jako u sloupcu 
	public static final boolean[] FIRST_ROW = generateRowArray(0);
	public static final boolean[] EIGHTH_ROW = generateRowArray(7);*/
	
	/** pocet poli v sachovnici */
	public static final int TILES_COUNT = 64;
	/** pocet poli v jedne radce (a vlastne i ve sloupci)*/
	public static final int TILES_IN_ROW = 8;

	
	
	/**
	 * Metoda, ktera vygeneruje boolean hodnoty pro zadane cislo sloupce
	 * @param columnNumber cislo sloupce
	 * @return pole booleanu reprezentujici dany sloupec
	 */
	private static boolean[] generateColumnArray(int columnNumber) {
		final boolean[] column = new boolean[TILES_COUNT];
		
		while(columnNumber < TILES_COUNT) {
			column[columnNumber] = true;
			columnNumber += TILES_IN_ROW;
		}
		return column;
	}
	
	/**
	 * Metoda, ktera vygeneruje boolean hodnoty pro zadane cislo radky
	 * @param rowNumber cislo radku
	 * @return pole booleanu reprezentujici danou radku
	 */
	private static boolean[] generateRowArray(int rowNumber) {
		final boolean[] row = new boolean[TILES_COUNT];
		
		if(rowNumber < 8) {
			int start = rowNumber * 8;
			for(int i = 0; i < TILES_IN_ROW; i++) {
				row[start++] = true;
			}
		}
		return row;
	}
	
	/**
	 * Metoda, ktera urci, zda je zadany index platny (nepresahuje hranice vymezene sachovnici ... 0-63)
	 * @param index index pole
	 * @return true, pokud je index pole platny, false, pokud neni
	 */
	public static boolean isValidTileIndex(int index) {
		if(index >= 0 && index < TILES_COUNT) {
			return true;
		}
		return false;
	}
	
}

