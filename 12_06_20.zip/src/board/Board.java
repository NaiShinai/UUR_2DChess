package board;

/**
 * Trida reprezentujici sachovnici
 * @author Jan Janis
 *
 */
public class Board {

	
	public Tile getTile(int tileIndex) {
		return null;
	}
	
}
