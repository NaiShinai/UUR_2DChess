package player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import board.Board;
import board.Move;
import board.MoveStatus;
import board.MoveTransition;
import pieces.Colors;
import pieces.King;
import pieces.Piece;

/**
 * Abstraktni trida predstavujici hrace
 * @author Jan Janis
 *
 */
public abstract class Player {
	/** herni sachovnice */
	protected final Board board;
	/** hracova figura krale */
	protected final King playerKing;
	/** kolekce dostupnych tahu */
	protected final Collection<Move> viableMoves;
	/** figura v sachu */
	private final boolean isInCheck;
	
	/** 
	 * Konstruktor
	 * @param board sachovnice
	 * @param viableMoves platne tahy hrace
	 * @param opponentsMoves platne tahy protihrace
	 */
	public Player(Board board, Collection<Move> viableMoves, Collection<Move> opponentsMoves) {
		this.board = board;
		this.playerKing = appointKing(); 
		this.viableMoves = Stream.concat(viableMoves.stream(), generateCastles(viableMoves, opponentsMoves).stream()).collect(Collectors.toList());
		this.isInCheck = !Player.generateAttacksOnTile(this.playerKing.getPieceIndex(), opponentsMoves).isEmpty();
	}
	
	/**
	 * Metoda, ktera vraci kolekci utocnych tahu na figuru na poli o zadanem indexu
	 * @param pieceIndex pole s figurou na kterou se utoci
	 * @param moves mozne tahy, ze kterych se urcuji utocne
	 * @return kolekce utocnych tahu na figuru o zadanem indexu
	 */
	protected static Collection<Move> generateAttacksOnTile(int pieceIndex, Collection<Move> moves) {
		List<Move> attackMoves = new ArrayList<>();
		
		for (Move move : moves) {
			if(pieceIndex == move.getDestinationIndex()) {
				attackMoves.add(move);
			}
		}
		return attackMoves;
	}
	
	/**
	 * Metoda, ktera z hernich figur urci krale
	 * @return figury krale
	 */
	private King appointKing() {
		for(Piece piece : getActivePieces()) {
			if(piece.getPieceType().isKing()) {
				return (King) piece;
			}
		}
		throw new RuntimeException("Sachovnice neobsahuje krale!");
	}
	
	/**
	 * Metoda, ktera urci, jestli je zadany tah platny
	 * @param move zadany tah
	 * @return true, pokud je platny, false, pokud ne
	 */
	public boolean isMoveViable(Move move) {
		return this.viableMoves.contains(move);
	}
	
	/**
	 * Metoda, ktera zjisti, zda je kral v sachu
	 * @return true, pokud ano, false, pokud ne
	 */
	public boolean isInCheck() {
		return this.isInCheck;
	}
	
	/**
	 * Metoda, ktera zjisti, zda je kral v sach matu
	 * @return true, pokud ano, false, pokud ne
	 */
	public boolean isInCheckMate() {
		return this.isInCheck && !hasEscapeMoves();
	}
	
	/**
	 * Metoda, ktera zjisti, zda existuji unikove tahy (lze udelat eventuelni pohyby do bezpeci)
	 * @return true, pokud existuji, false, pokud ne
	 */
	protected boolean hasEscapeMoves() {
		for (Move move : this.viableMoves) {
			MoveTransition transition = makeMove(move);
			if(transition.getMoveStatus().isDone()) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Metoda, ktera zjisti, zda existuje patova situace
	 * @return true, pokud ano, false, pokud ne
	 */
	public boolean isInStaleMate() {
		return !this.isInCheck && !hasEscapeMoves();
	}
	
	public boolean isCastled() { //rosada
		return false;
	}
	
	/**
	 * Metoda, ktera vraci prechod tahu, pokud byl tah uskutecnen
	 * @param move tah
	 * @return prechod tahu (ze startovniho pole na cilove)
	 */
	public MoveTransition makeMove(Move move) {
		//pokud neni tah platny, tah je neuskutecnitelny
		if(!isMoveViable(move)) {
			return new MoveTransition(this.board, move, MoveStatus.UNWORKABLE);
		}
		
		Board transitionBoard = move.execute();
		
		//kolekce utocnych tahu na hracova krale
		Collection<Move> kingAttacks = Player.generateAttacksOnTile(transitionBoard.currentPlayer().getOpponent().getPlayerKing().getPieceIndex(),
				transitionBoard.currentPlayer().getViableMoves());
		
		//pokud existuje nejaky utocny tah na krale, tah neuskutecni tah (nelze tahnout s kralem nekam, kde je v sachu)
		if(!kingAttacks.isEmpty()) {
			return new MoveTransition(this.board, move, MoveStatus.PLAYER_IN_CHECK);
		}
		
		return new MoveTransition(transitionBoard, move, MoveStatus.DONE);
	}
	
	/** Gettery */
	
	/**
	 * Metoda, ktera vrati figuru hracova krale
	 * @return figura hracova krale
	 */
	public King getPlayerKing() {
		return this.playerKing;
	}
	
	/**
	 * Metoda, ktera vrati kolekci platnych tahu
	 * @return kolekce platnych tahu
	 */
	public Collection<Move> getViableMoves() {
		return this.viableMoves;
	}
	
	/** Abstraktni metody */
	
	/** 
	 * Metoda, ktera vrati kolekci aktivnich figur
	 * @return kolekce aktivnich figur
	 */
	public abstract Collection<Piece> getActivePieces();
	
	/**
	 * Metoda, ktera vrati barvu hrace
	 * @return barva hrace
	 */
	public abstract Colors getColor();
	
	/**
	 * Metoda, ktera urci hracova protivnika
	 * @return hracuv protivnik
	 */
	public abstract Player getOpponent();
	
	/**
	 * Metoda, ktera vygeneruje rosady
	 * @param playersViables hracovy platne tahy
	 * @param opponentsViables protihracovi platne tahy
	 * @return kolekce rosad
	 */
	protected abstract Collection<Move> generateCastles(Collection<Move> playersViables, Collection<Move> opponentsViables);
}
