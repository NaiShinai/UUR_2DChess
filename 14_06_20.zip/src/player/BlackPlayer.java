package player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import board.Board;
import board.CastleMove;
import board.Move;
import board.Tile;
import pieces.Colors;
import pieces.Piece;
import pieces.Rook;

/**
 * Trida reprezentujici cerneho hrace
 * @author Jan Janis
 *
 */
public class BlackPlayer extends Player {
	
	/** konstruktor */
	public BlackPlayer(Board board, Collection<Move> whiteStandardViableMoves, Collection<Move> blackStandardViableMoves) {
		super(board, blackStandardViableMoves, whiteStandardViableMoves);
	}

	@Override
	public Collection<Piece> getActivePieces() {
		return this.board.getBlackPieces();
	}

	@Override
	public Colors getColor() {
		return Colors.BLACK;
	}

	@Override
	public Player getOpponent() {
		return this.board.getWhitePlayer();
	}

	@Override
	protected Collection<Move> generateCastles(Collection<Move> playersViables, Collection<Move> opponentsViables) {
		List<Move> kingCastles = new ArrayList<>();

		//pokud se jedna o prvni tah krale a zaroven kral neni v sachu
		if(this.playerKing.isFirstMove() && !this.isInCheck()) {
			//rosada ve smeru cerneho krale (doprava)
			//pokud neni obsazene pole o indexu 5 a 6
			if(!this.board.getTile(5).isOccupied() && !this.board.getTile(6).isOccupied()) {
				//pole, ktere je soucasti rosady
				Tile rookTile = this.board.getTile(7);

				//pokud je toto pole obsazene a jedna se o prvni pohyb 
				if(rookTile.isOccupied() && rookTile.getPiece().isFirstMove()) {
					//pokud nejsou figury na polich 5 a 6 pod hrozbou utoku a figura na tomto poli vez
					//prida mozny tah rosadou
					if(Player.generateAttacksOnTile(5, opponentsViables).isEmpty() &&
							Player.generateAttacksOnTile(6, opponentsViables).isEmpty() &&
							rookTile.getPiece().getPieceType().isRook()) {
						
						kingCastles.add(new CastleMove.KingSideCastleMove(this.board, this.playerKing, 6, (Rook) rookTile.getPiece(), rookTile.getTileIndex(), 5));
					}

				}
			}
			//rosada ve smeru cerne damy (doleva)
			//pokud neni obsazene pole o indexu 1, 2 a 3
			if(!this.board.getTile(1).isOccupied() && !this.board.getTile(2).isOccupied() &&
					!this.board.getTile(3).isOccupied()) {
				//pole ktere je soucasti rosady
				Tile rookTile = this.board.getTile(0);
				
				//pokud je toto pole obsazeno a jedna se o prvni pohyb, prida mozny tah rosadou
				if(rookTile.isOccupied() && rookTile.getPiece().isFirstMove()) {
					
					kingCastles.add(new CastleMove.KingSideCastleMove(this.board, this.playerKing, 2, (Rook) rookTile.getPiece(), rookTile.getTileIndex(), 3));
				}
			}


		}
		return kingCastles;
	}
}
