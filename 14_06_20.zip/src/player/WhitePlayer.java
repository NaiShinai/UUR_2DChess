package player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import board.Board;
import board.CastleMove;
import board.Move;
import pieces.Colors;
import pieces.Piece;
import pieces.Rook;
import board.Tile;

/**
 * Trida reprezentujici bileho hrace
 * @author Jan Janis
 *
 */
public class WhitePlayer extends Player {

	/** konstruktor */
	public WhitePlayer(Board board, Collection<Move> whiteStandardViableMoves, Collection<Move> blackStandardViableMoves) {
		super(board, whiteStandardViableMoves, blackStandardViableMoves);
	}

	@Override
	public Collection<Piece> getActivePieces() {
		return this.board.getWhitePieces();
	}

	@Override
	public Colors getColor() {
		return Colors.WHITE;
	}

	@Override
	public Player getOpponent() {
		return this.board.getBlackPlayer();
	}

	@Override
	protected Collection<Move> generateCastles(Collection<Move> playersViables, Collection<Move> opponentsViables) {
		List<Move> kingCastles = new ArrayList<>();

		//pokud se jedna o prvni tah krale a zaroven kral neni v sachu
		if(this.playerKing.isFirstMove() && !this.isInCheck()) {
			//rosada ve smeru bileho krale (doprava)
			//pokud neni obsazene pole o indexu 61 a 62
			if(!this.board.getTile(61).isOccupied() && !this.board.getTile(62).isOccupied()) {
				//pole, ktere je soucasti rosady
				Tile rookTile = this.board.getTile(63);

				//pokud je toto pole obsazene a jedna se o prvni pohyb 
				if(rookTile.isOccupied() && rookTile.getPiece().isFirstMove()) {
					//pokud nejsou figury na polich 61 a 62 pod hrozbou utoku a figura na tomto poli vez
					//prida mozny tah rosadou
					if(Player.generateAttacksOnTile(61, opponentsViables).isEmpty() &&
							Player.generateAttacksOnTile(62, opponentsViables).isEmpty() &&
							rookTile.getPiece().getPieceType().isRook()) {
			
						kingCastles.add(new CastleMove.KingSideCastleMove(this.board, this.playerKing, 62, (Rook) rookTile.getPiece(), rookTile.getTileIndex(), 61));
					}

				}
			}
			//rosada ve smeru bile damy (doleva)
			//pokud neni obsazene pole o indexu 59, 58 a 57
			if(!this.board.getTile(59).isOccupied() && !this.board.getTile(58).isOccupied() &&
					!this.board.getTile(57).isOccupied()) {
				//pole ktere je soucasti rosady
				Tile rookTile = this.board.getTile(56);
				
				//pokud je toto pole obsazeno a jedna se o prvni pohyb, prida mozny tah rosadou
				if(rookTile.isOccupied() && rookTile.getPiece().isFirstMove()) {
					
					kingCastles.add(new CastleMove.QueenSideCastleMove(this.board, this.playerKing, 58, (Rook) rookTile.getPiece(), rookTile.getTileIndex(), 59));
				}
			}


		}
		return kingCastles;
	}
}
