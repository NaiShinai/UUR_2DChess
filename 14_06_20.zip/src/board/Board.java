package board;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import pieces.Bishop;
import pieces.Colors;
import pieces.King;
import pieces.Knight;
import pieces.Pawn;
import pieces.Piece;
import pieces.Queen;
import pieces.Rook;
import player.BlackPlayer;
import player.Player;
import player.WhitePlayer;

/**
 * Trida reprezentujici sachovnici
 * @author Jan Janis
 *
 */
public class Board {
	/** sachovnice */
	private final List<Tile> gameBoard;
	/** cerne figury */
	private final Collection<Piece> blackPieces;
	/** bile figury */
	private final Collection<Piece> whitePieces;
	/** cerny hrac */
	private final BlackPlayer blackPlayer;
	/** bily hrac */
	private final WhitePlayer whitePlayer;
	/** hrac na tahu */
	private final Player currentPlayer;

	/** konstruktor */
	private Board(BoardBuilder builder) {
		this.gameBoard = createGameBoard(builder);
		this.blackPieces = generateActivePieces(this.gameBoard, Colors.BLACK);
		this.whitePieces = generateActivePieces(this.gameBoard, Colors.WHITE);
		
		Collection<Move> whiteStandardViableMoves = generateViableMoves(this.whitePieces);
		Collection<Move> blackStandardViableMoves = generateViableMoves(this.blackPieces);
		
		this.blackPlayer = new BlackPlayer(this, whiteStandardViableMoves, blackStandardViableMoves);
		this.whitePlayer = new WhitePlayer(this, whiteStandardViableMoves, blackStandardViableMoves);
		this.currentPlayer = builder.nextMoveMaker.choosePlayer(this.whitePlayer, this.blackPlayer);
	}


	/**
	 * Metoda, ktera vrati kolekci aktivnich hernich figur zadane barvy
	 * @param gameBoard sachovnice
	 * @param color barva figury
	 * @return list aktivnich hernich figur zadane barvy
	 */
	private static  Collection<Piece> generateActivePieces(List<Tile> gameBoard, Colors color) {
		List<Piece> activePieces = new ArrayList<>();

		for (Tile tile : gameBoard) {
			if(tile.isOccupied()) {
				Piece piece = tile.getPiece();
				if (piece.getPieceColor() == color) {
					activePieces.add(piece);
				}
			}
		}
		return activePieces;
	}
	
	/**
	 * Metoda, ktera vrati pole na zadanem indexu
	 * @param tileIndex index pole
	 * @return pole na zadanem indexu
	 */
	public Tile getTile(int tileIndex) {
		return gameBoard.get(tileIndex);
	}
	
	/**
	 * Metoda, ktera vrati cerneho hrace
	 * @return cerny hrac
	 */
	public Player getBlackPlayer() {
		return this.blackPlayer;
	}
	
	/**
	 * Metoda, ktera vrati bileho hrace
	 * @return bily hrac
	 */
	public Player getWhitePlayer() {
		return this.whitePlayer;
	}
	
	/**
	 * Metoda, ktera vrati hrace na tahu
	 * @return hrac na tahu
	 */
	public Player currentPlayer() {
		return this.currentPlayer;
	}
	
	/**
	 * Metoda, ktera vraci kolekci cernych figur
	 * @return kolekce cernych figur
	 */
	public Collection<Piece> getBlackPieces() {
		return this.blackPieces;
	}
	
	/**
	 * Metoda, ktera vraci kolekci bilych figur
	 * @return kolekce bilych figur
	 */
	public Collection<Piece> getWhitePieces() {
		return this.whitePieces;
	}
	
	/**
	 * Metoda, ktera vytvori platne tahy pro kazdou figuru z predane kolekce figur
	 * @param pieces kolekce figur
	 * @return list obsahujici platne tahy pro kazdou figuru
	 */
	private Collection<Move> generateViableMoves(Collection<Piece> pieces) {
		List<Move> viableMoves = new ArrayList<>();
		
		for (Piece piece : pieces) {
			viableMoves.addAll(piece.generateViableMoves(this));
		}
		return viableMoves;
	}
	
	/**
	 * toString metoda pro vyjadreni sachovnice s figurami
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		for(int i = 0; i < BoardUtils.TILES_COUNT; i++) {
			String tileString = this.gameBoard.get(i).toString();
			builder.append(String.format("%3s", tileString));
			
			if((i+1) % BoardUtils.TILES_IN_ROW == 0) {
				builder.append("\n");
			}
		}
		return builder.toString();
	}

	/**
	 * Metoda ktera zaplni sachovnici figurami
	 * @param builder pomocna trida 
	 * @return sachovnice
	 */
	private static List<Tile> createGameBoard(BoardBuilder builder) {
		//pole poli sachovnic
		final Tile[] tiles = new Tile[BoardUtils.TILES_COUNT];

		//pro kazde pole sachovnice
		for (int i = 0; i < tiles.length; i++) {
			//vytvori nove pole s figurou podle konfigurace
			tiles[i] = Tile.createTile(i, builder.boardConfiguration.get(i));
		}
		return Arrays.asList(tiles);
	}

	/**
	 * Metoda, ktera pomoci pomocne tridy BoardBuilder vytvori sachovnici s pocatecnim nastavenim figur
	 * @return sachovnice s figurami na startovnich pozicich (indexech)
	 */
	public static Board createStandardBoard() {
		BoardBuilder builder = new BoardBuilder();
		//cerne figury
		builder.setPiece(new Rook(0, Colors.BLACK));
		builder.setPiece(new Knight(1, Colors.BLACK));
		builder.setPiece(new Bishop(2, Colors.BLACK));
		builder.setPiece(new Queen(3, Colors.BLACK));
		builder.setPiece(new King(4, Colors.BLACK));
		builder.setPiece(new Bishop(5, Colors.BLACK));
		builder.setPiece(new Knight(6, Colors.BLACK));
		builder.setPiece(new Rook(7, Colors.BLACK));
		//cerni pesaci
		for(int i = 8; i <= 15; i++) {
			builder.setPiece(new Pawn(i, Colors.BLACK));
		}
		//bile figury
		//bili pesaci
		for(int i = 48; i <= 55; i++) {
			builder.setPiece(new Pawn(i, Colors.WHITE));
		}
		builder.setPiece(new Rook(56, Colors.WHITE));
		builder.setPiece(new Knight(57, Colors.WHITE));
		builder.setPiece(new Bishop(58, Colors.WHITE));
		builder.setPiece(new Queen(59, Colors.WHITE));
		builder.setPiece(new King(60, Colors.WHITE));
		builder.setPiece(new Bishop(61, Colors.WHITE));
		builder.setPiece(new Knight(62, Colors.WHITE));
		builder.setPiece(new Rook(63, Colors.WHITE));		

		return builder.build();
	}

	/**
	 * Vrati kolekci spojenych platnych tahu obou hracu
	 * @return
	 */
	public Collection<Move> getAllViableMoves() {
		//spoji platne tahy obou hracu a vrati jako list
		return Stream.concat(this.whitePlayer.getViableMoves().stream(), 
				this.blackPlayer.getViableMoves().stream()).collect(Collectors.toList());
	}

	/**
	 * Pomocna trida k vytvoreni sachovnice (builder pattern)
	 * @author Jan Janis
	 *
	 */
	public static class BoardBuilder {
		/** konfigurace sachovnice */
		Map<Integer, Piece> boardConfiguration;
		/** osoba, ktera je jako dalsi na tahu */
		Colors nextMoveMaker;
		/** pesak, ktery skocil o dve pole */
		Pawn enPassantPawn;

		/** konstruktor */
		public BoardBuilder() {
			this.boardConfiguration = new HashMap<>();
		}

		/**
		 * Metoda, ktera nastavi figuru na pole sachovnice
		 * @param piece nastavena figura
		 * @return this
		 */
		public BoardBuilder setPiece(Piece piece) {
			this.boardConfiguration.put(piece.getPieceIndex(), piece);
			return this;
		}

		/**
		 * Metoda, ktera nastavi osobu, ktera hraje jako dalsi
		 * @param nextMoveMaker barva osoby, ktera hraje jako dalsi
		 * @return this
		 */
		public BoardBuilder setMoveMaker(Colors nextMoveMaker) {
			this.nextMoveMaker = nextMoveMaker;
			return this;
		}

		/**
		 * Metoda, ktera vytvori sachovnici
		 * @return sachovnice
		 */
		public Board build() {
			return new Board(this);
		}
		
		/**
		 * Nastavi pesaka jako en passant (pesaka, ktery provedl prave skok 
		 * @param enPassantPawn
		 */
		public void setEnPassantPawn(Pawn enPassantPawn) {
			this.enPassantPawn = enPassantPawn;
		}
	}

}
