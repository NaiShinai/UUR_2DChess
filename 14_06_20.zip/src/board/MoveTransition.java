package board;

/**
 * Trida predstavujici prechod tahu (ze startovniho pole na cilove)
 * @author Jan Janis
 *
 */
public class MoveTransition {
	/** sachovnice na kterou se presune figura po pohybu */
	private final Board transitionBoard;
	/** vykonany pohyb*/
	private final Move move;
	/** typ tahu */
	private final MoveStatus moveStatus;
	
	/** konstruktor */
	public MoveTransition(Board transitionBoard, Move move, MoveStatus moveStatus) {
		this.transitionBoard = transitionBoard;
		this.move = move;
		this.moveStatus = moveStatus;
	}
	
	/**
	 * Metoda, ktera vraci typ tahu
	 * @return stav tahu
	 */
	public MoveStatus getMoveStatus() {
		return this.moveStatus;
	}
}
