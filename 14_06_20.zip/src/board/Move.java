package board;

import board.Board.BoardBuilder;
import pieces.Piece;

/**
 * Abstraktni trida reprezentujici pohyb (tah) figury
 * @author Jan Janis
 *
 */
public abstract class Move {
	/** sachovnice */
	public final Board board;
	/** figura se kterou je tazeno */
	public final Piece movedPiece;
	/** index pole, na ktery figura tahne */
	public final int destinationIndex;
	/** "prazdny" tah */
	public static final Move NULL_MOVE = new NullMove();

	/**
	 * Konstruktor tridy Move
	 * @param board sachovnice
	 * @param movedPiece figura, se kterou se hybe
	 * @param destinationIndex index na ktery se presune
	 */
	public Move(Board board, Piece movedPiece, int destinationIndex) {
		this.board = board;
		this.movedPiece = movedPiece;
		this.destinationIndex = destinationIndex;
	}

	@Override
	public int hashCode() {
		int result = 1;

		result = 31 * result + this.destinationIndex;
		result = 31 * result + this.movedPiece.hashCode();

		return result;

	}

	@Override
	public boolean equals(Object other) {
		if(this == other) {
			return true;
		}
		if(!(other instanceof Move)) {
			return false;
		}
		Move otherMove = (Move) other;

		return getDestinationIndex() == otherMove.getDestinationIndex() &&
				getMovedPiece().equals(otherMove.getMovedPiece());
	}

	/**
	 * Metoda, ktera vraci index pole, na kterem stoji tazena figury
	 * @return index aktualniho pole
	 */
	public int getCurrentIndex() {
		return this.getMovedPiece().getPieceIndex();
	}

	/**
	 * Metoda, ktera vraci index ciloveho pole (po tahu)
	 * @return index ciloveho pole
	 */
	public int getDestinationIndex() {
		return this.destinationIndex;
	}

	/**
	 * Metoda, ktera vrati tazenou figuru
	 * @return figura, se kterou se tahlo
	 */
	public Piece getMovedPiece() {
		return this.movedPiece;
	}

	/**
	 * Vrati napadenou figuru
	 * @return napadena figura
	 */
	public Piece getAttackedPiece() {
		return null;
	}

	/**
	 * Urci, zda je pohyb utokem
	 * @return true, pokud ano, false, pokud ne
	 */
	public boolean isAttack() {
		return false;
	}

	/**
	 * Urci, zda je pohyb rosadou
	 * @return true, pokud ano, false, pokud ne
	 */
	public boolean isCastlingMove() {
		return false;
	}

	/**
	 * Metoda, ktera vykona pohyb (predstavi novou sachovnici s vykonanym tahem)
	 * @return nova sachovnice s uskutecnenym tahem
	 */
	public Board execute() {
		BoardBuilder builder = new BoardBuilder();

		//pro vsechny figury aktualniho hrace, umisti na novou sachovnici figury, kterymi se netahne
		for (Piece piece : this.board.currentPlayer().getActivePieces()) {
			if(!this.movedPiece.equals(piece)) {
				builder.setPiece(piece);
			}
		}

		//pro vsechny figury soupere aktualniho hrace, umisti na novou sachovnici jeho figury
		for (Piece piece : this.board.currentPlayer().getOpponent().getActivePieces()) {
			builder.setPiece(piece);
		}

		//tahne s vybranou figurou
		builder.setPiece(this.movedPiece.movePiece(this));
		//na tahu je nyni protihrac
		builder.setMoveMaker(this.board.currentPlayer().getOpponent().getColor());

		return builder.build();
	}
}
