package board;

/**
 * Trida pomoci ktere se vytvari tahy
 * @author Jan Janis
 *
 */
public class MoveFactory {
	
	/**
	 * Metoda, ktera vytvori novy tah
	 * @param board herni sachovnice
	 * @param currentIndex index aktualniho pole
	 * @param destinationIndex index ciloveho pole
	 * @return tah z aktualniho pole na cilove pole
	 */
	public static Move createMove(Board board, int currentIndex, int destinationIndex) {
		for(Move move : board.getAllViableMoves()) {
			if(move.getCurrentIndex() == currentIndex && move.getDestinationIndex() == destinationIndex) {
				return move;
			}
		}
		return Move.NULL_MOVE;
	}
}
