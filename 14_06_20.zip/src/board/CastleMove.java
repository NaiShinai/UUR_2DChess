package board;

import board.Board.BoardBuilder;
import pieces.Piece;
import pieces.Rook;

/**
 * Abstraktni trida predstavujici tah rosadou
 * @author Jan Janis
 *
 */
public abstract class CastleMove extends Move {
	/** vez, ktera je soucasti rosady */
	protected final Rook castleRook;
	/** jeji pocatecni index */
	protected final int castleRookStart;
	/** jeji koncovy index */
	protected final int castleRookDest;

	/** konstruktor */
	public CastleMove(Board board, Piece movedPiece, int destinationIndex, Rook castleRook,
			int castleRookStart, int castleRookDest) {
		super(board, movedPiece, destinationIndex);
		this.castleRook = castleRook;
		this.castleRookStart = castleRookStart;
		this.castleRookDest = castleRookDest;
	}

	/**
	 * Metoda, ktera vrati vez, ktera je soucasti rosady
	 * @return vez, ktera je soucasti rosady
	 */ 
	public Rook getCastleRook() {
		return this.castleRook;
	}

	@Override
	public boolean isCastlingMove() {
		return true;
	}

	@Override
	public Board execute() {
		BoardBuilder builder = new BoardBuilder();

		for (Piece piece : this.board.currentPlayer().getActivePieces()) {
			//pokud neni figura ta se kterou se tahne a neni ani vezi, ktera je soucasti rosady
			//umisti ji na novou sachovnici
			if(!this.movedPiece.equals(piece) && !this.castleRook.equals(piece)) {
				builder.setPiece(piece);
			}
		}
		for (Piece piece : this.board.currentPlayer().getOpponent().getActivePieces()) {
			builder.setPiece(piece);
		}

		builder.setPiece(this.movedPiece.movePiece(this));
		//todo
		builder.setPiece(new Rook(this.castleRookDest, this.castleRook.getPieceColor()));
		builder.setMoveMaker(this.board.currentPlayer().getOpponent().getColor());

		return builder.build();

	}

	/**
	 * Trida predstavujici tah rosadou ve smeru krale
	 * @author Jan Janis
	 *
	 */
	public static class KingSideCastleMove extends CastleMove {

		/** konstruktor */
		public KingSideCastleMove(Board board, Piece movedPiece, int destinationIndex, Rook castleRook,
				int castleRookStart, int castleRookDest) {
			super(board, movedPiece, destinationIndex, castleRook, castleRookStart, castleRookDest);

		}
		
		@Override
		public String toString() {
			return "O-O"; //vyjadreni rosady ve smeru krale (o 2 pole)
		}

	}

	/**
	 * Trida predstavujici tah rosadou ve smeru damy
	 * @author Jan Janis
	 *
	 */
	public static class QueenSideCastleMove extends CastleMove {

		/** konstruktor */
		public QueenSideCastleMove(Board board, Piece movedPiece, int destinationIndex, Rook castleRook,
				int castleRookStart, int castleRookDest) {
			super(board, movedPiece, destinationIndex, castleRook, castleRookStart, castleRookDest);
		}
		
		@Override
		public String toString() {
			return "O-O-O"; //vyjadreni rosady ve smeru damy (o 2 pole)
		}
	}
}