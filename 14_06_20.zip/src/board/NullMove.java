package board;


/**
 * Trida predstavujici nulovy tah
 * @author Jan Janis
 *
 */
public class NullMove extends Move {

	/** konstruktor */
	public NullMove() {
		super(null, null, -1);
	}

	@Override
	public Board execute() {
		throw new RuntimeException("Tento tah nelze provest");
	}
}
