package board;

import pieces.Piece;

/**
 * Trida reprezentujici utocny tah pesaka
 * @author Jan Janis
 *
 */
public class PawnAttackMove extends AttackMove {

	public PawnAttackMove(Board board, Piece movedPiece, int destinationIndex, Piece attackedPiece) {
		super(board, movedPiece, destinationIndex, attackedPiece);
	}

}
