package board;

import pieces.Pawn;
import pieces.Piece;
import board.Board.BoardBuilder;

/**
 * Predstavuje skok s pesakem o 2 pole
 * @author Jan Janis
 *
 */
public class PawnJump extends Move {

	public PawnJump(Board board, Piece movedPiece, int destinationIndex) {
		super(board, movedPiece, destinationIndex);
	}

	@Override
	public Board execute() {
		BoardBuilder builder = new BoardBuilder();
		
		for (Piece piece : this.board.currentPlayer().getActivePieces()) {
			if(!this.movedPiece.equals(piece)) {
				builder.setPiece(piece);
			}
		}
		for (Piece piece : this.board.currentPlayer().getOpponent().getActivePieces()) {
			builder.setPiece(piece);
		}
		Pawn movedPawn = (Pawn) this.movedPiece.movePiece(this);
		
		builder.setPiece(movedPawn);
		//pokud doslo ke skoku, nastavi pesaka jako en passant
		builder.setEnPassantPawn(movedPawn);
		builder.setMoveMaker(this.board.currentPlayer().getOpponent().getColor());
		
		return builder.build();
	}
	
	
}
