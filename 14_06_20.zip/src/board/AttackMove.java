package board;

import pieces.Piece;

/**
 * Trida reprezentujici utocny tah
 * @author Jan Janis
 *
 */
public class AttackMove extends Move {
	/** figura, ktera je napadena */
	final Piece attackedPiece;

	/** konstruktor */
	public AttackMove(Board board, Piece movedPiece, int destinationIndex, Piece attackedPiece) {
		super(board, movedPiece, destinationIndex);
		this.attackedPiece = attackedPiece;

	}


	@Override
	public int hashCode() {
		return this.attackedPiece.hashCode() + super.hashCode();
	}

	@Override
	public boolean equals(Object other) {
		if(this == other) {
			return true;
		}
		if(!(other instanceof AttackMove)) {
			return false;
		}
		AttackMove otherAttackMove = (AttackMove) other;
		return super.equals(otherAttackMove) && getAttackedPiece().equals(otherAttackMove.getAttackedPiece());
	}

	@Override
	public Board execute() {
		return null;
	}

	@Override
	public boolean isAttack() {
		return true;
	}

	@Override
	public Piece getAttackedPiece() {
		return this.attackedPiece;
	}
}
