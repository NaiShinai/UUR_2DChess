package board;

/**
 * Vycet reprezentujici typy tahu
 * @author Jan Janis
 *
 */
public enum MoveStatus {
	/** vykonany tah */
	DONE {
		@Override
		public boolean isDone() {
			return true;
		}
	},
	/** neuskutecnitelny tah */
	UNWORKABLE {
		@Override
		public boolean isDone() {
			return false;
		}
	},
	/** tah, ktery by vystavil hrace do sachu */
	PLAYER_IN_CHECK {
		@Override
		public boolean isDone() {
			return false;
		}
	};

	/**
	 * Metoda, ktera urci tah jako hotovy
	 * @return true, false
	 */
	public abstract boolean isDone();

}
