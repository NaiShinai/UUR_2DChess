package board;

import pieces.Piece;

/**
 * Trida reprezentujici en passant tah pesakem
 * @author Jan Janis
 *
 */
public class PawnEnPassantAttackMove extends PawnAttackMove{

	public PawnEnPassantAttackMove(Board board, Piece movedPiece, int destinationIndex, Piece attackedPiece) {
		super(board, movedPiece, destinationIndex, attackedPiece);
	}

}
