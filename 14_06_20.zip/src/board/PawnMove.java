package board;

import pieces.Piece;

/**
 * Trida predstavujici tah pesaka
 * @author Jan Janis
 *
 */
public class PawnMove extends Move{

	/** konstruktor */
	public PawnMove(Board board, Piece movedPiece, int destinationIndex) {
		super(board, movedPiece, destinationIndex);
	}

}

