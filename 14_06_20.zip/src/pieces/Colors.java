package pieces;

import player.BlackPlayer;
import player.Player;
import player.WhitePlayer;

/**
 * Vycet predstavujici barvy
 * @author Jan Janis
 *
 */
public enum Colors {
	BLACK {
		@Override
		public int getDirection() {
			return 1;
		}

		@Override
		public boolean isBlack() {
			return true;
		}

		@Override
		public boolean isWhite() {
			return false;
		}

		@Override
		public Player choosePlayer(WhitePlayer whitePlayer, BlackPlayer blackPlayer) {
			return blackPlayer;
		}
	}, 
	WHITE {
		@Override
		public int getDirection() {
			return -1;
		}

		@Override
		public boolean isBlack() {
			return false;
		}

		@Override
		public boolean isWhite() {
			return true;
		}

		@Override
		public Player choosePlayer(WhitePlayer whitePlayer, BlackPlayer blackPlayer) {
			return whitePlayer;
		}
	};
	
	/**
	 * Metoda, ktera vraci prirozeny smer pohybu figur
	 * Cerne figury maji horni polovinu sachovnice
	 * Bile figury maji dolni polovinu sachovnice
	 * @return -1 pro bile (tahnou "nahoru", takze do minusovych indexu)
	 * 			1 pro cerne (tahnou "dolu", takze do plusovych indexu)
	 */
	public abstract int getDirection();
	
	/**
	 * Metoda, ktera vraci boolean o barve figury
	 * @return true, pokud je figura cerna, false pokud ne
	 */
	public abstract boolean isBlack();
	
	/**
	 * Metoda, ktera vraci boolean o barve figury
	 * @return true, pokud je figura bila, false pokud ne
	 */
	public abstract boolean isWhite();
	
	/**
	 * Metoda, ktera zvoli hrace
	 * @param whitePlayer bily hrac
	 * @param blackPlayer cerny hrac
	 * @return hrac jedne barvy
	 */
	public abstract Player choosePlayer(WhitePlayer whitePlayer, BlackPlayer blackPlayer);
	
}
