package pieces;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import board.AttackMove;
import board.Board;
import board.BoardUtils;
import board.MajorMove;
import board.Move;


/**
 * Trida reprezentujici pesaka.
 * @author Jan Janis
 *
 */
public class Pawn extends Piece {
	/** mozne indexy poli v sachovnici, na ktere se muze pesak pohnout (z pohledu jeho aktualni pozice) */
	private final static int[] POSSIBLE_MOVE_INDEXES = {7, 8, 9, 16};

	/** konstruktor */
	public Pawn(int pieceIndex, Colors pieceColor) {
		super(pieceIndex, pieceColor, PieceType.PAWN);
	}

	@Override
	public Collection<Move> generateViableMoves(Board board) {
		// kolekce moznych tahu
		final List<Move> viableMoves = new ArrayList<>();

		for (int currentPossibleOffset : POSSIBLE_MOVE_INDEXES) {
			//index pole, na ktere muze jezdec tahnout
			int possibleDestinationIndex = this.pieceIndex + (this.pieceColor.getDirection() * currentPossibleOffset);

			//pokud je index pole platny
			if(!BoardUtils.isValidTileIndex(possibleDestinationIndex)) {
				continue;
			}

			//pokud neni pole destinace obsazene
			if(currentPossibleOffset == 8 && !board.getTile(possibleDestinationIndex).isOccupied()) {
				viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));

				//pokud je to prvni tah s pesakem, a dany pesak je cerny ve druhe rade, nebo bily v sedme rade
			} else if(currentPossibleOffset == 16 && this.isFirstMove() && 
					(BoardUtils.SECOND_ROW[this.pieceIndex] && this.getPieceColor().isBlack()) || 
					(BoardUtils.SEVENTH_ROW[this.pieceIndex] && this.getPieceColor().isWhite())) {

				//index pole ktere je o dve rady pred (za) pesakem
				int behindPossibleDestinationIndex = this.pieceIndex + (this.pieceColor.getDirection() * 8);

				//pokud neni obsazeno pole pred(za) pesakem ani pole o radu dal, prida mozny tah
				if(!board.getTile(behindPossibleDestinationIndex).isOccupied() && !board.getTile(possibleDestinationIndex).isOccupied()) {
					viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));
				}

				//pokud neni pesak v osmem sloupci a neni bily nebo pokud neni v prvnim sloupci a neni cerny (pripady ve kterych by byl index 7 neplatny)
			} else if(currentPossibleOffset == 7 && !((BoardUtils.EIGHTH_COLUMN[this.pieceIndex] && this.pieceColor.isWhite() ||
					(BoardUtils.FIRST_COLUMN[this.pieceIndex] && this.pieceColor.isBlack())))) {

				//pokud neni pole mozne destinace obsazeno
				if(board.getTile(possibleDestinationIndex).isOccupied()) {
					//figura na moznem poli
					Piece pieceOnPossibleIndex = board.getTile(possibleDestinationIndex).getPiece();

					//pokud je barva figury na moznem poli odlisna od barvy tahnute figury, prida mozny utocny tah
					if(this.pieceColor != pieceOnPossibleIndex.getPieceColor()) {
						//TODO
						viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));

					}
				}

				//pokud neni pesak v prvnim sloupci a neni bily nebo pokud neni v osmem sloupci a neni cerny (pripady ve kterych by byl index 9 neplatny)
			} else if(currentPossibleOffset == 9 && !((BoardUtils.FIRST_COLUMN[this.pieceIndex] && this.pieceColor.isWhite() ||
					(BoardUtils.EIGHTH_COLUMN[this.pieceIndex] && this.pieceColor.isBlack())))) {
				
				//pokud neni pole mozne destinace obsazeno
				if(board.getTile(possibleDestinationIndex).isOccupied()) {
					//figura na moznem poli
					Piece pieceOnPossibleIndex = board.getTile(possibleDestinationIndex).getPiece();

					//pokud je barva figury na moznem poli odlisna od barvy tahnute figury, prida mozny utocny tah
					if(this.pieceColor != pieceOnPossibleIndex.getPieceColor()) {
						//TODO
						viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));

					}
				}
			}
		}

		return viableMoves;
	}

	@Override
	public Pawn movePiece(Move move) {
		return new Pawn(move.getDestinationIndex(), move.getMovedPiece().getPieceColor());
	}
	
	@Override
	public String toString() {
		return PieceType.PAWN.toString();
	}
}
