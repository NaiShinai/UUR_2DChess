package pieces;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import board.AttackMove;
import board.Board;
import board.Move;
import board.Tile;
import board.BoardUtils;
import board.MajorMove;

/**
 * Trida reprezentujici figuru jezdce
 * @author Jan Janis
 *
 */
public class Knight extends Piece {
	/** mozne indexy poli v sachovnici, na ktere se jezdec muze pohnout (z pohledu jeho aktualni pozice) */
	private final static int[] POSSIBLE_MOVE_INDEXES = {-17, -15, -10 -6, 6, 10, 15, 17};

	/** konstruktor */
	public Knight(int pieceIndex, Colors pieceColor) {
		super(pieceIndex, pieceColor, PieceType.KNIGHT);
	}

	@Override
	public Collection<Move> generateViableMoves(Board board) {
		// kolekce moznych tahu
		final List<Move> viableMoves = new ArrayList<>();

		for (int currentPossibleOffset : POSSIBLE_MOVE_INDEXES) {
			//index pole, na ktere muze jezdec tahnout
			int possibleDestinationIndex = this.pieceIndex + currentPossibleOffset;

			//pokud je index dostupny
			if(BoardUtils.isValidTileIndex(possibleDestinationIndex)) {
				
				//pokud narazi na hranici, preskoci
				if(isFirstColumnExclusion(this.pieceIndex, currentPossibleOffset) || isSecondColumnExclusion(this.pieceIndex, currentPossibleOffset) ||
						isSeventhColumnExclusion(this.pieceIndex, currentPossibleOffset) || isEighthColumnExclusion(this.pieceIndex, currentPossibleOffset)) {
					continue;
				}
				
				//mozne cilove pole
				final Tile possibleDestinationTile = board.getTile(possibleDestinationIndex);

				//pokud neni pole obsazeno, prida mozny tah do kolekce
				if(!possibleDestinationTile.isOccupied()) {
					viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));
				}
				else {
					//figura na poli o moznem indexu tahu
					final Piece pieceAtDestination = possibleDestinationTile.getPiece();
					//barva teto figury
					final Colors pieceColor = pieceAtDestination.getPieceColor();

					//pokud je figura (na poli o moznem indexu) jine barvy, nez aktualni figura, prida mozny utocny tah do kolekce
					if(this.pieceColor != pieceColor) {
						viableMoves.add(new AttackMove(board, this, possibleDestinationIndex, pieceAtDestination));
					}
				}
			}

		}
		return viableMoves;
	}
	
	/**
	 * Tyto metody slouzi k vylouceni neplatnych tahu (tzn. neplatnych indexu cilovych poli) jezdce
	 * @param currentIndex soucasny index pole, na kterem je figura
	 * @param possibleOffset mozny index pole destinace
	 * @return true, pokud se nachazi figura v prislusnem sloupci (0,1,6,7) a zaroven se mozny index destinace rovna jednomu ze "zakazanych" indexu (takovych, ktere jsou mimo dosah tahu jezdce)
	 * 		   pokud se figura nenachazi v prislusnem sloupci, nebo se mozny index destinace rovna jednomu ze zakazanych indexu, vraci false  
	 */
	private static boolean isFirstColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.FIRST_COLUMN[currentIndex] && (possibleOffset == -17 || possibleOffset == -10 || possibleOffset == 6 || possibleOffset == 15);
	}

	private static boolean isSecondColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.SECOND_COLUMN[currentIndex] && (possibleOffset == -10 || possibleOffset == 6);
	}

	private static boolean isSeventhColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.SEVENTH_COLUMN[currentIndex] && (possibleOffset == -6 || possibleOffset == 10);
	}

	private static boolean isEighthColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.EIGHTH_COLUMN[currentIndex] && (possibleOffset == -15 || possibleOffset == -6 || possibleOffset == 10 || possibleOffset == 17);
	}
	
	@Override
	public Knight movePiece(Move move) {
		return new Knight(move.getDestinationIndex(), move.getMovedPiece().getPieceColor());
	}
	
	@Override
	public String toString() {
		return PieceType.KNIGHT.toString();
	}
}
