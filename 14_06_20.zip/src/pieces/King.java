package pieces;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import board.AttackMove;
import board.Board;
import board.BoardUtils;
import board.MajorMove;
import board.Move;
import board.Tile;


/**
 * Trida reprezentujici krale
 * @author Jan Janis
 *
 */
public class King extends Piece {
	/** mozne indexy poli v sachovnici, na ktere se muze pesak pohnout (z pohledu jeho aktualni pozice) */
	private final static int[] POSSIBLE_MOVE_INDEXES = {-9, -8, -7, -1, 1, 7, 8, 9};

	/** konstruktor */
	public King(int pieceIndex, Colors pieceColor) {
		super(pieceIndex, pieceColor, PieceType.KING);
	}

	@Override
	public Collection<Move> generateViableMoves(Board board) {
		// kolekce moznych tahu
		final List<Move> viableMoves = new ArrayList<>();

		for(int currentPossibleOffset : POSSIBLE_MOVE_INDEXES) {
			//index pole, na ktere muze kral tahnout
			int possibleDestinationIndex = this.pieceIndex + currentPossibleOffset;
			
			//pokud narazi na hranici, preskoci
			if(isFirstColumnExclusion(this.pieceIndex, currentPossibleOffset) || isEighthColumnExclusion(this.pieceIndex, currentPossibleOffset)) {
				continue;
			}

			//pokud je index pole platny
			if(BoardUtils.isValidTileIndex(possibleDestinationIndex)) {
				//mozne cilove pole
				final Tile possibleDestinationTile = board.getTile(possibleDestinationIndex);

				//pokud neni pole obsazeno, prida mozny tah do kolekce
				if(!possibleDestinationTile.isOccupied()) {
					viableMoves.add(new MajorMove(board, this, possibleDestinationIndex));
				}
				else {
					//figura na poli o moznem indexu tahu
					final Piece pieceAtDestination = possibleDestinationTile.getPiece();
					//barva teto figury
					final Colors pieceColor = pieceAtDestination.getPieceColor();

					//pokud je figura (na poli o moznem indexu) jine barvy, nez aktualni figura, prida mozny utocny tah do kolekce
					if(this.pieceColor != pieceColor) {
						viableMoves.add(new AttackMove(board, this, possibleDestinationIndex, pieceAtDestination));
					}
				}
			}
		}

		return viableMoves;
	}
	
	/**
	 * Tyto metody slouzi k vylouceni neplatnych tahu (tzn. neplatnych indexu cilovych poli) krale
	 * @param currentIndex soucasny index pole, na kterem je figura
	 * @param possibleOffset mozny index pole destinace
	 * @return true, pokud se nachazi figura v prislusnem sloupci (0,7) a zaroven se mozny index destinace rovna jednomu ze "zakazanych" indexu (takovych, ktere jsou mimo dosah tahu krale)
	 * 		   pokud se figura nenachazi v prislusnem sloupci, nebo se mozny index destinace rovna jednomu ze zakazanych indexu, vraci false  
	 */
	private static boolean isFirstColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.FIRST_COLUMN[currentIndex] && (possibleOffset == -9 || possibleOffset == -1 || possibleOffset == 7);
	}

	private static boolean isEighthColumnExclusion(int currentIndex, int possibleOffset) {
		return BoardUtils.EIGHTH_COLUMN[currentIndex] && (possibleOffset == -7 || possibleOffset == 1 || possibleOffset == 9);
	}
	
	@Override
	public King movePiece(Move move) {
		return new King(move.getDestinationIndex(), move.getMovedPiece().getPieceColor());
	}
	
	@Override
	public String toString() {
		return PieceType.KING.toString();
	}
}
