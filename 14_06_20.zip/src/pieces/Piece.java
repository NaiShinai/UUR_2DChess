package pieces;

import java.util.Collection;


import board.Board;
import board.Move;

/**
 * Abstraktni trida reprezentujici sachovou figuru
 * @author Jan Janis
 *
 */
public abstract class Piece {
	/** index sachove figury */
	protected final int pieceIndex;
	/** barva figury */
	protected final Colors pieceColor;
	/** typ figury */
	protected final PieceType pieceType;
	/** je tah prvnim tahem */
	protected final boolean isFirstMove;
	/** hash kod */
	private final int hashCode;
	
	/**
	 * Konstruktor sachove figury
	 * @param pieceIndex index figury
	 * @param pieceColor barva figury
	 */
	public Piece(int pieceIndex, Colors pieceColor, PieceType pieceType) {
		this.pieceIndex = pieceIndex;
		this.pieceColor = pieceColor;
		this.pieceType = pieceType;
		this.isFirstMove = false;
		this.hashCode = computeHashCode();
	}
	
	/**
	 * Porovna figuru s objektem
	 * @param other jiny objekt
	 * @return true, pokud se rovnaji, jinak vrati false
	 */
	@Override
	public boolean equals(Object other) {
		if(this == other) {
			return true;
		}
		if(!(other instanceof Piece)) {
			return false;
		}
		Piece otherPiece = (Piece) other;
		return pieceIndex == otherPiece.getPieceIndex() && pieceType == otherPiece.getPieceType() &&
				pieceColor == otherPiece.getPieceColor() && isFirstMove == otherPiece.isFirstMove();
	}
	
	/**
	 * urci adresu prvku v pameti jako int
	 * @return int
	 */
	private int computeHashCode() {
		int result = pieceType.hashCode();
		result = 31 * result + pieceColor.hashCode();
		result = 31 * result + pieceIndex;
		if(isFirstMove) {
			result = 31 * result + 1;
		}
		else {
			result = 31 * result + 0;
		}
		return result; 
	}
	
	/**
	 * Vraci adresu objektu v pameti jako int
	 */
	@Override
	public int hashCode() {
		return this.hashCode;
	}
	/**
	 * Metoda, ktera vrati index pole, na kterem je figura
	 * @return index pole, na kterem je figura
	 */
	public int getPieceIndex() {
		return this.pieceIndex;
	}
	

	
	/**
	 * Metoda, ktera vraci typ figury
	 * @return typ figury
	 */
	public PieceType getPieceType() {
		return this.pieceType;
	}
	
	/**
	 * Metoda, ktera vrati barvu figury
	 * @return barva figury
	 */
	public Colors getPieceColor() {
		return this.pieceColor;
	}
	
	/**
	 * Metoda, ktera vrati boolean hodnotu 
	 * @return true, pokud se jedna o prvni pohyb s figurou, false, pokud ne
	 */
	public boolean isFirstMove() {
		return this.isFirstMove;
	}
	
	/**
	 * Metoda, ktera vygeneruje mozne pohyby s figurami (dle pravidel)
	 * @param board sachovnice
	 * @return list moznych tahu
	 */
	public abstract Collection<Move> generateViableMoves(Board board);
	
	/**
	 * Metoda, ktera vykona tah na vybrane figure, a vrati novou figuru s jinou pozici
	 * @return stejna figura, ale s jinou pozici
	 */
	public abstract Piece movePiece(Move move);
	
	/**
	 * Vycet predstavujici typy  figur
	 * @author Jan Janis
	 */
	public enum PieceType {
		/** vez */
		ROOK("V") {
			@Override
			public boolean isKing() {
				return false;
			}

			@Override
			public boolean isRook() {
				return true;
			}
		}, 
		/** jezdec */
		KNIGHT("J") {
			@Override
			public boolean isKing() {
				return false;
			}

			@Override
			public boolean isRook() {
				return false;
			}
		}, 
		/** strelec */
		BISHOP("S") {
			@Override
			public boolean isKing() {
				return false;
			}

			@Override
			public boolean isRook() {
				return false;
			}
		},
		/** dama */
		QUEEN("D") {
			@Override
			public boolean isKing() {
				return false;
			}

			@Override
			public boolean isRook() {
				return false;
			}
		}, 
		/** kral */
		KING("K") {
			@Override
			public boolean isKing() {
				return true;
			}

			@Override
			public boolean isRook() {
				return false;
			}
		}, 
		/** pesak */
		PAWN("P") {
			@Override
			public boolean isKing() {
				return false;
			}

			@Override
			public boolean isRook() {
				return false;
			}
		};
		
		/** nazev figury */
		private String pieceName;
		
		/** konstruktor */
		PieceType(String pieceName) {
			this.pieceName = pieceName;
		}
		
		/**
		 * Metoda, ktera urcuje, zda je dana figura kral
		 * @return true, pokud ano, false, pokud ne
		 */
		public abstract boolean isKing();
		
		/**
		 * Metoda, ktera urcuje, zda je dana figura vez
		 * @return true pokud ano, false pokud ne
		 */
		public abstract boolean isRook();
		
		@Override
		public String toString() {
			return this.pieceName;
		}
	}
}
